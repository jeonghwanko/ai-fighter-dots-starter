# 부츠의 분리된 접촉면 검토

`fighter:contact`는 AI Fighter 제작 키트가 유지하는 **명시적 검토 근거 확장**이다. 번들 sprite-gen 소스와 핀을 바꾸거나
공식 모듈을 monkey-patch하지 않는다. 기본 `inspect-motion`은 그대로이며, `footEvidence`를 지정한 접지 구간만 확장을 사용한다.
확장 보고서에는 공식 `upstream_report` 전체와 적용 근거가 함께 남는다. 공식 sprite-gen이 수정됐다고 표현하지 않는다.

## 지원 범위와 한계

공식 검사기의 하단 2픽셀 띠는 부츠의 굽과 앞창도 두 접촉면으로 볼 수 있다. 반면 연결된 두 발도 비슷한 모양을 만들 수 있다.
따라서 연결성·일정한 이동만으로 경고를 제거하지 않는다. 검토자가 실제 프레임마다 **양쪽 해부학적 발 전체**를 구분해서
표시하고 같은 발·발 전체·반대 발 제외·지면 접촉을 모두 확인해야 한다. `near`/`far`는 화면상 앞뒤에 따라 바꾸지 않는다.

이 선언은 시각 검토에 의존한다. 잘못된 해부학적 라벨이나 거짓 검토를 이미지 마스크만으로 완전히 검출할 수 있다고 주장하지 않는다.
가림 때문에 두 발을 구분하거나 발 전체를 표시할 수 없으면 `unverified`로 유지한다. 로컬 제작 근거이며 서버 보안 인증서가 아니다.

확장은 다음을 모두 요구한다.

- 전체 시퀀스 RGBA 픽셀·프레임 크기·재생 시간, 발 이름·접지 구간·ROI·방향이 템플릿 생성 당시와 일치한다.
- 모든 접지 프레임에 두 발의 단순 다각형 윤곽과 굽·앞창 접촉점이 있다. 좌표는 실제 캔버스의 정수 픽셀이다.
- 각 윤곽이 독립적인 연결된 발 하나를 가리킨다. 두 윤곽의 불투명 픽셀이 겹치지 않고, 반대 발이 ROI 안에 들어가지 않는다.
- 선언된 발 전체가 ROI 안에 있으며, ROI의 불투명 픽셀 전부가 해당 발에 속한다. 밑창을 제외하거나 일부만 추적하지 않는다.
- 굽·앞창 표식은 실제 하단 띠의 불투명 픽셀에 있고, 두 접촉면이 있다면 각각 하나씩 가리킨다.
- 두 접촉면 사이 간격은 발 외곽 너비의 30% 이내이며, 위로 합쳐지는 깊이는 발 높이의 20%와 너비의 12%를 올림한 값 중 작은 값 이내다.
  이는 현재의 보수적인 형상 제한이지 해부학 판정의 정확도 확률이 아니다. CLI로 한계를 느슨하게 바꿀 수 없다.
- 공식 검사의 다른 실패(잘림, 면적/크기 변화, 수직 이동, 역방향 전환, 속도 불일치, 관찰 자세 부족 등)가 하나도 없다.

조건을 만족했을 때만 기존에 계산된 후보 속도를 검증값으로 채택한다. 속도를 수기로 받지 않는다.
두 발이 섞였거나, 근거가 없거나 오래됐거나, 깊고 넓은 틈/3개 이상 접촉면이면 계속 미검증이다.
보행 루프·정체성·해부학·양발 교대의 시각 검수와 최종 패키징 게이트는 별도로 유지된다.

## 사용 순서

먼저 일반 `fighter:gait review`를 실행해 현재 프레임의 `review/measurement/sequence.json`을 만든다.
다음은 **명령 구조 예시**다. 발 전체를 포함하는 실제 접지 구간과 ROI로 바꾼다. 기존 좁은 ROI가 부츠 윗부분을 잘랐다면
발 전체를 보며 다시 지정한다. 통과하는 좌표를 탐색해서 선택하지 않는다.

```sh
npm run fighter:contact -- template --source review/measurement/sequence.json --contacts 1:3 --foot-box 232,400,126,61 --foot near --facing right --out near-foot.json
```

템플릿의 `sequence`·`stance`는 편집하지 않는다. 이미지나 ROI가 바뀌면 새 파일로 템플릿을 다시 만든다. 기존 파일은 덮어쓰지 않는다.
`review.reviewer`에는 실제 검토 주체(예: agent visual review)를, `notes`에는 어떤 그림에서 어떻게 같은 발을 구분했는지 기록한다.
`method`는 `visual-per-frame`이며 네 검토 항목을 실제 관찰에 따라 `pass`로 바꾼다. 추정으로 통과시키지 않는다.

각 `frames` 항목을 다음 구조로 채운다. 아래 빈 배열은 그대로는 미검증이다.

```json
{
  "frame": 1,
  "nearOutline": [],
  "farOutline": [],
  "heel": [],
  "forefoot": []
}
```

윤곽은 `[[x,y], ...]` 3~128개 꼭짓점이고 처음 점을 끝에 반복하지 않는다. `heel`·`forefoot`는 측정할 발의 `[x,y]`다.
반대 발의 윤곽도 실제로 표시한다. 동일 좌표를 모든 프레임에 복사하거나, 다른 발을 몸통으로 표시해 제외하지 않는다.

확인용 단독 실행:

```sh
npm run fighter:contact -- inspect --source review/measurement/sequence.json --contacts 1:3 --foot-box 232,400,126,61 --foot near --facing right --foot-evidence near-foot.json --out near-contact.json
```

양쪽 접지 구간 각각의 근거를 만든 뒤 annotations의 해당 stance에 `footEvidence` 경로를 넣는다.
이 경로는 **annotations JSON의 폴더 기준**이다. `box`, `start`, `end`는 증거 파일과 일치해야 한다.

```json
{"foot":"near","start":1,"end":3,"box":[232,400,126,61],"footEvidence":"near-foot.json"}
```

```sh
npm run fighter:gait -- review walk-plan.json review annotations.json
```

새 보고서의 `measurement_engine`은 `ai-fighter-foot-evidence-v1`이다. 공식 결과는 `upstream_report`, 추가 판정·윤곽·검토는
`foot_evidence`에 남는다. 단독 접지 측정이 성공해도 전체 보행이 실패하면 `review.json.status`는 실패이고 보폭은 `null`이다.
등록 전 미리보기의 지면·접지 영역 표시를 켜면 선언한 양발 윤곽과 굽·앞창 점도 실제 프레임 위에 겹쳐진다.
최종 game-pack의 픽셀이나 배율·시간이 달라지면 새 템플릿과 새 윤곽 검토가 필요하다. `fighter:pack`은 최종 시퀀스와 맞는 근거만 받는다.

## 회귀 검사

```sh
node --test test/contact-evidence.test.mjs test/gait.test.mjs test/gait-engine.test.mjs test/pack.test.mjs
```

실제 번들 검사기와 합성 측정 fixture로 단일 부츠의 조건부 통과, 연결된 두 발/분리된 두 발/잘못된 ROI/밑창 잘림/
미할당 픽셀/근거 누락/해시·시간 변경/접촉점 오류/깊은 틈/공중 이동/속도 불일치/시각 루프 실패를 확인한다.
합성 fixture는 등록 가능한 캐릭터가 아니다. Rook 등 실제 캐릭터의 윤곽과 검토를 대신하지 않는다.
