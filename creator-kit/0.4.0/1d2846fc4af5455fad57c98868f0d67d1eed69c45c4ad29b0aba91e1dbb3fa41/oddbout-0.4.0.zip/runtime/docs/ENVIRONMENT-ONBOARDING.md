# Dots 제작 환경 연결

첫 구현은 **GPT 외형 제작의 계정 연결**이다. 새 캐릭터 생성이나 기존 작품 재생성 권한을
부여하지 않는다. 외형을 현재 대화에서 직접 생성·표시할 수 있으면 `DELIVERY.md`의 직접 경로를
먼저 확인한다. 그 경로에 VM 설치나 별도 CLI 로그인을 강제하지 않는다.

## 사용자 흐름

1. 캐릭터 설명/참고 이미지를 먼저 받는다. 기존 제작이면 선택한 버전과 작업 기록부터 복원한다.
2. `get_creation_environment`로 연결 상태를 읽는다. 없으면 현재 단계에 필요한 본인 계정만 묻는다.
   GPT / Grok / 둘 다 선택과 이미지·영상 기능 확인은 별도 사실이다. 이미 받은 답은 다시 묻지 않는다.
3. `update_creation_environment`의 `configure`로 사용자의 실제 선택·발언을 기록한다.
4. 반환된 `plan`의 목적·도메인·환경 범위를 보여주고 호스트의 네트워크 승인 절차를 이용한다.
   그 절차에서 받은 승인이 같은 목록/범위에 해당하면 다시 승인받지 않고 `approve-network`로 기록한다.
   사용자의 발언이나 호스트 승인 결과가 없으면 승인 기록을 만들지 않는다.
5. 호스트의 실제 적용 결과를 확인하고 `report-host-network`에 근거를 기록한다.
   이어 `check-network`로 bootstrap 주소의 HTTPS 도달 여부를 검사한다.
6. 계정 연결 요청 범위에서 `prepare_generation_login`을 호출하고 반환된 `execution`의 명령·인자·cwd를
   그대로 호스트 실행 도구로 실행한다. `awaiting-user`의 공개 로그인 링크와 확인 코드만 보여준다.
   사용자가 공식 제공자 페이지에서 로그인하면 실행이 끝나고 `get_creation_environment`로 상태를 다시 읽는다.
7. 생성·원본 전달·현재 대화의 미리보기 사전 조건을 별도로 확인한다. 실제 요청한 첫 시안으로 생성과 표시를 확인한다.
   로그인 검사나 네트워크 검사 때문에 새 테스트 이미지를 생성하지 않는다.

명령은 `creation:tool`로도 사용 가능하다. 인자를 JSON 파일로 작성하고 실행한다.

```sh
npm run creation:tool -- call <absolute-workspace> get_creation_environment
npm run creation:tool -- call <absolute-workspace> update_creation_environment <arguments.json>
npm run creation:tool -- call <absolute-workspace> prepare_generation_login
```

최초 configure 인자 예시(값은 실제 사용자 답으로 채운다):

```json
{
  "expectedRevision": 0,
  "change": {
    "type": "configure",
    "account": "gpt",
    "host": "dots",
    "conversationId": "current-conversation-id",
    "confirmedAccess": ["gpt-image"],
    "feedback": "사용자가 실제로 말한 계정 연결 요청과 이미지 접근 확인"
  }
}
```

`confirmedAccess`는 아직 확인하지 못했으면 빈 배열이다. 계정 선택으로 채우지 않는다.
모든 변경은 최신 `revision`을 `expectedRevision`으로 사용한다. 충돌하면 다시 읽고 의도를 재평가한다.
새 대화에서는 configure로 실제 conversationId와 기존 선택을 이어받고 전달 사전 조건을 갱신한다.

## 상태의 의미

| 항목 | 확인하는 것 | 확인하지 않는 것 |
| --- | --- | --- |
| 계정 선택 | 사용자가 요청한 제공자와 개별 기능 확인 | 로그인·잔여 한도 |
| generation | 같은 실행 환경의 공식 `codex login status` 결과 | 이미지 백엔드·사용자 동일성·이미지 생성 성공 |
| network.approved | 표시한 planHash에 대한 승인 기록 | 방화벽 변경 |
| network.application | 15분 이내 호스트 적용 관찰 기록 | 도구가 직접 검증한 권한 증명 |
| network.reachability | 승인/적용 기록 뒤 수행한 HEAD 응답 | 생성 API 권한·모든 다운로드/CDN·브라우저/커넥터 네트워크 |
| delivery | 현재 환경/대화에 묶인 전달 사전 조건 기록 | 실제 파일 업로드·대화 표시 |

`readyForWorkflow`는 기존의 설치/선택 준비 상태다. `readyForGeneration`은 여기에 환경의 사전 조건 기록이
충족되어야 true다. 어느 값도 생성 요청, 성공, 검수, 사용자 선택의 대체물이 아니다.
현재 adapter는 GPT 외형만 준비한다. Grok 또는 GPT+Grok 선택은 보존하지만 Grok 로그인을 자동 실행하지 않는다.
이후 영상 단계는 기존 sprite-gen workflow에서 별도로 확인하며, GPT로 조용히 대체하지 않는다.

`delivery` 변경은 workspace-relative JSON 경로를 받는다. 기존 `delivery-check.json`의 `environment`에는
반환된 environmentId, `conversationId`에는 현재 대화 ID를 쓴다. 파일 내용 해시가 바뀌거나 다른 대화이면
다시 확인한다. 사전 조건의 근거는 실제 호스트/도구 관찰에서 기록한다.

## 프로필과 웹 배포

`deploy/creation-environments.json`은 버전이 있는 선언적 bootstrap 목록이다. 현재 GPT 인증·요청 주소만 포함한다.
실제 생성 결과 CDN과 Dots 전달 경로는 미검증 항목으로 명시한다. 완전한 운영 allowlist로 취급하지 않는다.
설치용 주소나 다른 제공자 주소를 무조건 더하지 않으며, 미확인 도메인을 오류 메시지에서 자동 승인하지 않는다.

사이트 빌드는 공개 `/creation-environments/v1.json`을 산출물에 넣는다. 개인 환경 ID·승인·인증 정보는 포함하지 않는다.
`refresh-profile`은 설정된 공개 사이트의 고정 경로만 읽고 redirect를 거부한다. 읽기 실패는 기존 기록을 보존한다.

- 번들과 동일한 프로필은 정규화된 콘텐츠 SHA-256으로 확인한다. 첫 접속에도 번들 목록을 쓸 수 있다.
- 변경된 원격 콘텐츠는 `deploy/creation-environment-trust.json`에 **별도 설치된** Ed25519 공개 키가 있어야 한다.
  기본 키 목록은 비어 있으므로 변경된 원격 목록은 거부한다. 배포 담당자가 키를 준비하기 전에는 서명 업데이트가 활성화되지 않는다.
- envelope는 `{ "profile": ..., "keyId": ..., "signature": "base64" }`다. 서명 대상은 `canonical(profile)`의 UTF-8 바이트다.
  비밀 키는 이 저장소·플러그인·공개 웹사이트에 넣지 않는다. 키 배포와 서명은 릴리스 운영에서 수행한다.
- revision 감소, 같은 revision의 다른 내용, 알 수 없는 필드, wildcard·IP·내부 호스트는 거부한다.
- 새 내용은 기존 승인/호스트 적용/접속/전달 기록을 무효화한다. 새 목록을 보여주고 필요한 승인을 받는다.

현재 `hostAdapter`는 **manual-handoff**다. Dots의 관리형 네트워크를 변경하는 공개 API가 확인되지 않아
자동 적용을 구현했다고 표시하지 않는다. 직접 운영하는 VM의 방화벽 어댑터도 아직 연결하지 않았다.
`report-host-network`의 근거가 있어도 source는 항상 `host-reported`이며 라이브 인증서로 승격하지 않는다.
`revoke-network`는 로컬 승인만 해제한다. 실제 호스트 권한 해제는 별도 수행해야 한다.

## 인증·보존·복구

공식 `codex login --device-auth`를 사용한다. 설치된 CLI의 help에 옵션이 있어야 시작한다.
ChatGPT의 기기 로그인 설정/조직 정책 때문에 거부되면 중단한다. 콜백 주소·토큰·API 키 붙여넣기를 제안하지 않는다.
토큰 파일을 직접 읽거나 복사하지 않으며 공식 CLI가 현재 사용자의 자격 증명 저장소를 관리한다.
CLI와 이후 sprite-gen은 같은 사용자 전용 workspace와 CODEX_HOME/환경에서 실행해야 한다.
로그인 성공을 이미지 기능이나 Dots 대화 계정 동일성으로 확대하지 않는다.

연결 상태는 `output/creation-environment/environment.json`에 보존한다. 호스트명·실제 workspace 경로·자격 증명 홈이 달라지면
다른 VM에 복사된 기록을 차단한다. 공개 코드 외 CLI 출력은 메모리에서만 처리하고 로그/도구 응답으로 내보내지 않는다.
`get_creation_environment`는 이때 현재 revision과 `rebind` 조치를 반환한다. 사용자가 새 환경에서 연결을 요청하면
최신 revision으로 `rebind`(host, conversationId, feedback)를 기록한다. 캐릭터 파일·계정 선택은 보존하며
기능 확인·네트워크 승인·전달 확인만 초기화한다. 자격 증명을 옮기지 않는다.
로그인은 환경 잠금을 유지하므로 겹쳐 실행되지 않는다. 프로세스 강제 종료로 잠금이 남으면 실제 실행 상태부터 확인한다.
잠금을 자동 삭제하고 재시도하지 않는다. 인증 중단은 캐릭터 재생성 권한이 아니다.

## 검증 범위

로컬 테스트는 상태 보존, 승인/적용 분리, 서명·변조·롤백, 출력 비밀정보 제거, MCP 연결, 로그인 실행 명령을 검증한다.
실제 Dots 계정 연결·네트워크 권한 UI·첫 시안 표시의 종단간 검증은 별도 사용자 세션에서 수행해야 한다.
해당 검증 없이 VM 지원이나 생성 성공을 선언하지 않는다.

## Library 전송 장애 이후의 전달 계획 (2026-10-26)

미미의 기존 기록에서는 Library 목록 조회가 성공했지만, VM helper가 공용 hosted apps 브리지의
`tools/list`를 호출할 때 `network` 오류로 끝났다. helper 소스의 호출 순서상 `prepare_materialize`와
다운로드 URL 수신 전 단계다. 정확한 브리지 목적지와 축약 전 네트워크 오류는 미확인이며, 403이나
특정 도메인 차단의 증거는 없다. 이 장애를 ZIP 크기 문제나 생성 제공자 로그인 실패로 분류하지 않는다.

계획을 다음 세 경로로 나눈다. 각 단계가 성공해야 그 범위만 완료로 기록한다.

### 1. 공개 제작 키트: 경량 배포와 검토된 해시로 직접 받기

- `plugin:bundle`은 upstream `docs/assets/`의 문서 예제 미디어만 제외한다. 원본 체크아웃·gitlink·패치를
  변경하지 않고 실행 소스, 패키지 데이터, workflow 문서, LICENSE·NOTICE를 유지한다. 빠진 파일 목록과
  실제 해시는 build-report에 기록한다. runtime manifest는 포함된 실제 파일에서 다시 만든다.
- `kit:release`는 검증된 ZIP과 다운로드 helper를 묶어 `public/creator-kit/<version>/<content-id>/`를 준비한다.
  content-id는 ZIP과 helper의 해시에 함께 묶인다. 고정 URL은 immutable 후보이며 `latest` 자동 업데이트는 없다.
  준비 상태는 `prepared-not-published`다. URL을 만들었다고 서버 게시나 VM 도달 성공으로 기록하지 않는다.
- 최초 신뢰 기준은 **별도로 검토한 release-report의 manifest/helper 해시**다. 같은 서버에서 ZIP과 체크섬을
  함께 받았다는 사실만으로 실행을 허용하지 않는다. 자동 업데이트용 서명 키 배포는 이후 별도 릴리스 작업이다.
- `fetch-creator-kit.py`는 Python 표준 라이브러리만 사용한다. 공개 `oddbout.com`의 HTTPS 경로만 받고,
  리다이렉트·쿼리·다른 origin을 거부한다. 기존 프록시·CA 설정을 유지하며 인증/네트워크 설정은 변경하지 않는다.
  크기·전체 ZIP 해시·runtime 파일 목록과 개별 해시·경로·파일 형식을 검증한 뒤 **새 폴더**에 압축을 푼다.
  실행, 의존성 설치, 로그인, 생성은 하지 않는다. 실패 시 단계와 결과를 보존하고 자동 재시도하지 않는다.
- 릴리스의 networkPlan은 다운로드용 `oddbout.com:443`만 설명한다. npm/Python 설치, 생성 서비스, Library,
  사용자 파일 전달 허용과 다르다. 기존 generation profile에 download 성공이나 허용을 자동 기록하지 않는다.

구현 검증 순서:

1. 변경·손상된 파일, 리다이렉트, 크기 초과, 경로 탈출, 중복 경로, symlink, 기존 목적지 거부 테스트.
2. 실제 경량 ZIP을 로컬 파일 모드로 해시 검사·압축 해제하고 분리된 사용자 runtime에서 설치·도구 호출 확인.
3. `public/` 하위의 버전 경로만 **추가하는 방식**으로 배포한다. 기존 사이트 및 이전 릴리스를 보존하며,
   전체 사이트 교체용 `site:publish`에 이 릴리스 폴더를 넣지 않는다. 게시 후 세 파일의 실제 HTTPS 응답과 바이트를 확인한다.
4. 미미의 별도 검증 폴더에서 동일 manifest 해시로 실제 다운로드·압축 해제·설치를 확인한다. 기존 개구리 폴더는 유지한다.

다운로드·오프라인 압축 해제·로컬 설치·실제 VM HTTPS 전달은 별도 검증이다. Library 장애의 복구나
사용자 이미지 전달 성공으로 확대하지 않는다. 소프트웨어 다운로드 권한이 없으면 호스트의 공식 승인 절차를 따른다.

### 2. 사용자 제작 자료: 공식 플러그인 파일 입력과 비공개 작업 저장소

이 경로는 설계 단계다. 기존 `upload_fighter_asset`은 등록용 자산 업로드이므로 일반 원본·영상 보관에 재사용하지 않는다.
공식 플러그인의 `openai/fileParams` 입력으로 사용자가 선택한 파일을 받는 작은 실증부터 수행한다.
Dots가 해당 입력을 실제로 전달하는지 확인하기 전에는 지원된다고 표시하지 않는다.

후속 구현은 로그인한 사용자의 작업 소유권, 비공개 저장, 용량/형식 제한, 콘텐츠 해시, 멱등 요청,
만료되는 다운로드 권한을 함께 다룬다. 파일 참조와 작업 상태는 보존하고 임시 URL 만료 때문에 재생성하지 않는다.
다운로드 URL은 서버에서 처리하며 대화·일반 로그에 노출하지 않는다. 임의 URL 다운로드 도구로 확대하지 않고
URL/redirect/내부 네트워크 접근을 검증한다. 파일 수신, 서버 저장, VM 수신, 해시 확인, 현재 대화 표시를 각각 기록한다.
불명확한 결과는 기존 작업/파일 기록을 조회한 뒤 판단한다. Library 보관·표시도 필요한 경우 별도 확인한다.

완료 기준은 비민감 작은 파일로 수신·재개·권한 분리·실제 VM 바이트 일치를 확인하는 것이다.
생성 테스트를 위해 새 이미지를 만들지 않으며, 기존 개구리 원본의 새 전송은 그 파일과 목적지에 대한 승인 범위에서 진행한다.

### 3. 준비된 실행 환경과 플랫폼 오류 진단

키트/의존성을 준비된 Codex 환경에 설치하면 반복 설치를 줄일 수 있다. 공통 환경에 개인 로그인이나
서비스 키를 넣지 않으며 사용자별 작업 공간을 유지한다. 환경 갱신은 새 작업에서 검증하고 기존 제작 작업을 초기화하지 않는다.
Library 오류는 별도로 실제 bridge 목적지, 축약 전 오류, 요청 시각을 플랫폼 측에서 확인해야 한다.
재로그인·도메인 확장·보안 우회를 일반적인 해결책으로 실행하지 않는다.

근거: [공식 파일 입력 API](https://developers.openai.com/plugins/reference#file-apis),
[Work 네트워크 범위](https://learn.chatgpt.com/docs/enterprise/chatgpt-work-cloud-security),
[Dots 실행 환경](https://learn.chatgpt.com/docs/dots/computers-and-apps),
[준비된 클라우드 환경](https://learn.chatgpt.com/docs/environments/cloud-environments).
